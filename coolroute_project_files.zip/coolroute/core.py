"""CoolRoute core: heat-exposure-aware pedestrian routing.

Simple idea
-----------
Every street piece (edge) has:
  length (m), shade (0..1), slope (%), step_free (True/False), confidence (0..1)
Heat exposure of an edge  =  length * (1 - shade) * sun(t)        [sun-metres]
Effort of an edge         =  length * (1 + 0.05 * slope%)         [effort-metres]
Crossings add a waiting time, which also adds heat if the crossing is unshaded.

Two routes:
  1. Baseline  : minimise distance only (classic shortest path).
  2. CoolRoute : minimise distance subject to heat <= budget.
     Solved with Lagrangian relaxation:  cost = distance + lambda * heat,
     and we search lambda by bisection (simple, fast, explainable).
"""
import heapq
import json
import math
import random

LAT = 26.9  # Jaipur latitude in degrees
WALK_SPEED = 1.3  # m/s


# ---------------------------------------------------------------- sun model
def sun_factor(hour, day_of_year=288):
    """Relative sun strength 0..1 for a given clock hour (solar time).
    sin(elevation) = sin(lat) sin(dec) + cos(lat) cos(dec) cos(h)
    """
    dec = math.radians(23.45 * math.sin(math.radians(360 / 365 * (day_of_year - 81))))
    lat = math.radians(LAT)
    h = math.radians(15 * (hour - 12))
    s = math.sin(lat) * math.sin(dec) + math.cos(lat) * math.cos(dec) * math.cos(h)
    return max(0.0, s)


# ------------------------------------------------------------ neighbourhood
def build_neighbourhood(n=8, spacing=80, seed=7):
    """Synthetic n x n street grid. Node id = r*n + c."""
    rnd = random.Random(seed)
    nodes = []
    for r in range(n):
        for c in range(n):
            nodes.append({"id": r * n + c, "x": c * spacing, "y": r * spacing})
    edges = []

    def add(a, b, kind):
        length = spacing * rnd.uniform(0.95, 1.1)
        # tree-lined avenue in column 2 and row 5 -> high shade
        ra, ca = divmod(a, n)
        rb, cb = divmod(b, n)
        shaded_line = (ca == cb == 2) or (ra == rb == 5)
        shade = rnd.uniform(0.65, 0.9) if shaded_line else rnd.uniform(0.0, 0.3)
        shade = round(shade, 2)
        slope = round(rnd.choice([0, 0, 0, 1, 2, 3, 6]), 1)
        step_free = rnd.random() > 0.12
        crossing = kind == "cross"
        wait = rnd.choice([10, 20, 35, 50]) if crossing else 0
        crossing_shade = round(rnd.uniform(0.0, 0.5), 2) if crossing else 0
        confidence = round(rnd.uniform(0.35, 1.0), 2)
        if rnd.random() < 0.1:
            confidence = round(rnd.uniform(0.0, 0.25), 2)  # missing data
        edges.append({
            "a": a, "b": b, "length": round(length, 1), "shade": shade,
            "slope": slope, "step_free": step_free, "wait": wait,
            "crossing_shade": crossing_shade, "confidence": confidence,
            "closed": False,
        })

    for r in range(n):
        for c in range(n):
            i = r * n + c
            if c + 1 < n:
                add(i, i + 1, "cross" if (r % 3 == 0 and c % 2 == 0) else "street")
            if r + 1 < n:
                add(i, i + n, "cross" if (c % 3 == 0 and r % 2 == 0) else "street")
    return {"n": n, "spacing": spacing, "nodes": nodes, "edges": edges}


# --------------------------------------------------------------- edge costs
def edge_metrics(e, sun, shade_on=True):
    shade = e["shade"] if shade_on else 0.0
    cshade = e["crossing_shade"] if shade_on else 0.0
    walk_heat = e["length"] * (1 - shade) * sun
    wait_heat = e["wait"] * WALK_SPEED * (1 - cshade) * sun  # waiting = standing in sun
    heat = walk_heat + wait_heat
    effort = e["length"] * (1 + 0.05 * e["slope"])
    time_s = e["length"] / WALK_SPEED + e["wait"]
    return {"dist": e["length"], "heat": heat, "effort": effort, "time": time_s}


def make_adj(g, sun, step_free_only=False, shade_on=True):
    adj = {nd["id"]: [] for nd in g["nodes"]}
    for k, e in enumerate(g["edges"]):
        if e["closed"]:
            continue
        if step_free_only and not e["step_free"]:
            continue  # HARD constraint
        m = edge_metrics(e, sun, shade_on)
        adj[e["a"]].append((e["b"], k, m))
        adj[e["b"]].append((e["a"], k, m))
    return adj


# ------------------------------------------------------------------ search
def dijkstra(adj, src, dst, lam):
    """Minimise dist + lam * heat. Returns (path_nodes, path_edges) or None."""
    best = {src: 0.0}
    prev = {}
    pq = [(0.0, src)]
    while pq:
        d, u = heapq.heappop(pq)
        if u == dst:
            break
        if d > best.get(u, 1e18):
            continue
        for v, k, m in adj[u]:
            nd = d + m["dist"] + lam * m["heat"]
            if nd < best.get(v, 1e18):
                best[v] = nd
                prev[v] = (u, k)
                heapq.heappush(pq, (nd, v))
    if dst not in best:
        return None
    nodes, eds = [dst], []
    while nodes[-1] != src:
        u, k = prev[nodes[-1]]
        eds.append(k)
        nodes.append(u)
    return nodes[::-1], eds[::-1]


def summarise(g, adj_edges, sun, shade_on=True):
    tot = {"dist": 0, "heat": 0, "effort": 0, "time": 0}
    low_conf = 0
    for k in adj_edges:
        e = g["edges"][k]
        m = edge_metrics(e, sun, shade_on)
        for key in tot:
            tot[key] += m[key]
        if e["confidence"] < 0.3:
            low_conf += 1
    tot["missing_edges"] = low_conf
    tot["n_edges"] = len(adj_edges)
    tot["data_confidence"] = (
        sum(g["edges"][k]["confidence"] for k in adj_edges) / max(1, len(adj_edges))
    )
    return tot


def plan(g, src, dst, hour, budget_pct=60, step_free_only=False, shade_on=True):
    """Return baseline + CoolRoute.

    budget_pct: allowed heat as % of the baseline route's heat (100 = no limit).
    """
    sun = sun_factor(hour)
    adj = make_adj(g, sun, step_free_only, shade_on)
    base = dijkstra(adj, src, dst, 0.0)
    if base is None:
        return {"error": "no_route", "sun": sun}
    base_s = summarise(g, base[1], sun, shade_on)
    budget = base_s["heat"] * budget_pct / 100.0

    # Lagrangian bisection on lambda
    lo, hi = 0.0, 50.0
    best = base
    best_s = base_s
    feasible = base_s["heat"] <= budget
    if not feasible:
        for _ in range(40):
            mid = (lo + hi) / 2
            r = dijkstra(adj, src, dst, mid)
            s = summarise(g, r[1], sun, shade_on)
            if s["heat"] <= budget:
                best, best_s, feasible = r, s, True
                hi = mid
            else:
                lo = mid
        if not feasible:  # budget impossible: return the coolest possible route
            r = dijkstra(adj, src, dst, hi)
            best, best_s = r, summarise(g, r[1], sun, shade_on)
    return {
        "sun": sun, "budget": budget, "budget_met": best_s["heat"] <= budget + 1e-9,
        "baseline": {"nodes": base[0], "edges": base[1], "m": base_s},
        "cool": {"nodes": best[0], "edges": best[1], "m": best_s},
    }


if __name__ == "__main__":
    g = build_neighbourhood()
    with open("graph.json", "w") as f:
        json.dump(g, f)
    r = plan(g, 0, 63, 13.0, 60)
    print(json.dumps({k: v for k, v in r.items() if k in ("sun", "budget", "budget_met")}))
    for key in ("baseline", "cool"):
        m = r[key]["m"]
        print(key, {k: round(v, 2) for k, v in m.items()})
