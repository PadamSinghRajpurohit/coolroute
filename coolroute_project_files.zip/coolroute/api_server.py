"""CoolRoute backend (Starlette). Same engine as core.py, exposed as a JSON API.

Run:  uvicorn api_server:app --port 8765
FastAPI is built on Starlette, so these routes move to FastAPI with almost no change
(and gain automatic /docs). Here we use Starlette only because it was available offline.
"""
import copy
import json
import math
from starlette.applications import Starlette
from starlette.responses import JSONResponse
from starlette.routing import Route

from core import build_neighbourhood, plan, sun_factor

GRAPH = build_neighbourhood()
N_EDGES = len(GRAPH["edges"])


def err(status, code, message):
    return JSONResponse({"error": {"code": code, "message": message}}, status_code=status)


def snap(point):
    """Accept {"node": id} or {"x": m, "y": m} (metres in the local map) and return a node id."""
    if "node" in point:
        n = point["node"]
        if not isinstance(n, int) or not 0 <= n < len(GRAPH["nodes"]):
            raise ValueError("node must be an integer from 0 to %d" % (len(GRAPH["nodes"]) - 1))
        return n
    if "x" in point and "y" in point:
        x, y = float(point["x"]), float(point["y"])
        return min(GRAPH["nodes"], key=lambda nd: (nd["x"] - x) ** 2 + (nd["y"] - y) ** 2)["id"]
    raise ValueError("point needs 'node' or both 'x' and 'y'")


def route_summary(g, side, shade_on, sun):
    e_ids = side["edges"]
    L = sum(g["edges"][k]["length"] for k in e_ids)
    shaded = sum(g["edges"][k]["length"] * (g["edges"][k]["shade"] if shade_on else 0) for k in e_ids)
    m = side["m"]
    return {
        "nodes": side["nodes"],
        "distance_m": round(m["dist"], 1),
        "walk_time_min": round(m["time"] / 60, 1),
        "heat_exposure": round(m["heat"], 1),
        "effort": round(m["effort"], 1),
        "shaded_share": round(shaded / L, 3) if L else 0,
        "data_confidence": round(m["data_confidence"], 2),
        "missing_data_segments": m["missing_edges"],
        "segments": m["n_edges"],
    }


def explain(r, base, cool):
    if r["sun"] == 0:
        return "There is no sun at this hour, so heat exposure is zero and both routes are the same."
    if r["baseline"]["edges"] == r["cool"]["edges"]:
        return "The shortest route already fits the heat budget, so CoolRoute keeps it."
    cut = 100 * (1 - cool["heat_exposure"] / base["heat_exposure"])
    extra = cool["distance_m"] - base["distance_m"]
    pct = 100 * (cool["distance_m"] / base["distance_m"] - 1)
    dt = cool["walk_time_min"] - base["walk_time_min"]
    return (f"CoolRoute is {extra:.0f} m longer ({pct:+.1f}%) and takes {abs(dt):.1f} min "
            f"{'more' if dt >= 0 else 'less'}, but cuts heat exposure by {cut:.0f}% by keeping to shaded streets.")


async def health(request):
    return JSONResponse({"status": "ok", "nodes": len(GRAPH["nodes"]), "edges": N_EDGES, "data": "synthetic"})


async def sun(request):
    try:
        hour = float(request.query_params.get("hour", "13"))
    except ValueError:
        return err(400, "BAD_INPUT", "hour must be a number between 0 and 24")
    if not 0 <= hour <= 24:
        return err(400, "BAD_INPUT", "hour must be a number between 0 and 24")
    return JSONResponse({"hour": hour, "sun_strength": round(sun_factor(hour), 4)})


async def graph(request):
    return JSONResponse({"nodes": GRAPH["nodes"], "edges": [
        {"id": k, **{key: e[key] for key in ("a", "b", "length", "shade", "step_free", "wait", "confidence")}}
        for k, e in enumerate(GRAPH["edges"])]})


async def route(request):
    try:
        body = await request.json()
    except Exception:
        return err(400, "BAD_JSON", "Request body must be valid JSON.")
    try:
        src, dst = snap(body["origin"]), snap(body["destination"])
        hour = float(body.get("hour", 13))
        budget = float(body.get("heat_budget_pct", 60))
        step_free = bool(body.get("step_free", False))
        shade_on = bool(body.get("shade_available", True))
        closed = body.get("closed_edge_ids", [])
        if not 0 <= hour <= 24:
            raise ValueError("hour must be between 0 and 24")
        if not 10 <= budget <= 100:
            raise ValueError("heat_budget_pct must be between 10 and 100")
        if not isinstance(closed, list) or any((not isinstance(c, int) or not 0 <= c < N_EDGES) for c in closed):
            raise ValueError("closed_edge_ids must be a list of edge ids from 0 to %d" % (N_EDGES - 1))
        if src == dst:
            raise ValueError("origin and destination are the same place")
    except KeyError as ex:
        return err(400, "BAD_INPUT", f"missing field {ex}")
    except (ValueError, TypeError) as ex:
        return err(400, "BAD_INPUT", str(ex))

    g = copy.deepcopy(GRAPH)
    for c in closed:
        g["edges"][c]["closed"] = True
    r = plan(g, src, dst, hour, budget, step_free, shade_on)
    if "error" in r:
        return err(404, "NO_ROUTE", "No route exists with the closed footpaths and step-free rule given.")

    base = route_summary(g, r["baseline"], shade_on, r["sun"])
    cool = route_summary(g, r["cool"], shade_on, r["sun"])
    warnings = []
    if not r["budget_met"]:
        warnings.append({"code": "BUDGET_NOT_MET", "message": "The heat budget cannot be met. This is the coolest route available."})
    if cool["distance_m"] > 1.2 * base["distance_m"]:
        warnings.append({"code": "LARGE_DETOUR", "message": "The cooler route adds more than 20% distance."})
    if cool["missing_data_segments"]:
        warnings.append({"code": "MISSING_DATA", "message": f"{cool['missing_data_segments']} of {cool['segments']} segments have missing shade data; heat value is approximate."})
    if step_free:
        warnings.append({"code": "STEP_FREE_HARD_RULE", "message": "Only step-free segments were used."})
    return JSONResponse({
        "sun_strength": round(r["sun"], 3), "heat_budget": round(r["budget"], 1), "budget_met": r["budget_met"],
        "baseline": base, "coolroute": cool, "explanation": explain(r, base, cool), "warnings": warnings,
        "note": "Heat exposure is a relative planning score, not a medical risk.",
    })


app = Starlette(routes=[
    Route("/api/v1/health", health), Route("/api/v1/sun", sun), Route("/api/v1/graph", graph),
    Route("/api/v1/route", route, methods=["POST"]),
])
